package com.example.smscall;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etBroj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etBroj = (EditText) findViewById(R.id.etBroj);
    }

    public void zovi(View view) {
        String telBroj = "tel: ";
        telBroj += etBroj.getText().toString();
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse(telBroj));
        startActivity(intent);
    }

    public void pripremiPoziv(View view) {
        String telBroj = "tel: ";
        telBroj +=etBroj.getText().toString();
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(telBroj));
        startActivity(intent);
    }
    public void pripremiSMS(View view){
        EditText etPoruka = (EditText) findViewById(R.id.etPoruka);
        EditText etbrojPor = (EditText) findViewById(R.id.etBrojPor);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.putExtra("address",etbrojPor.getText().toString());
        intent.putExtra("sms_body",etPoruka.getText().toString());
        intent.setType("vnd.android-dir/mms-sms");
        startActivity(intent);

    }
    public void saljiSMS(View view){
        try {
            EditText etPoruka = (EditText) findViewById(R.id.etPoruka);
            EditText etbrojPor = (EditText) findViewById(R.id.etBrojPor);
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(etbrojPor.getText().toString(), null, etPoruka.getText().toString(), null, null);
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), "Niste unijeli broj ili poruku", Toast.LENGTH_SHORT).show();
        }
    }
}